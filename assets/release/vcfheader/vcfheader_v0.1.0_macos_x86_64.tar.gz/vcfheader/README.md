# vcfheader (Rust CLI)

Standalone command line tool to parse VCF headers and generate a standalone HTML report.

This is a compiled alternative to the `vcfheader` R package. It does not require R. However we assume first that the R version is the current version and use it for exact output matching. 

## Development

`scripts/build_release.sh`

```bash
chmod +x scripts/build_release.sh
./scripts/build_release.sh
```

Quick manual run

```bash
./target/release/vcfheader parse fixtures/inputs/simple.vcf
./target/release/vcfheader report fixtures/inputs/sv44.vcf -o /tmp/sv44_vcfheader.html
open /tmp/sv44_vcfheader.html
```

## Packaging a public release

Releases are produced into a versioned folder inside the repo (for example `release_v0.1.0/`), containing tarballs and checksums per platform.

### Build release artefacts

From anywhere:

```bash
bash scripts/build_release.sh v0.1.0 macos_x86_64
```

Outputs:

* `release_v0.1.0/vcfheader_v0.1.0_macos_universal.tar.gz`
* `release_v0.1.0/vcfheader_v0.1.0_macos_universal.tar.gz.sha256`
* `release_v0.1.0/release_table.md`

The release_v0.1.0/ folder is just a convenient local staging area so you can keep the tarball, checksum, and table together, build multiple platforms into one place.

The internal directory contains: 

```text
release_v0.1.0/
├── release_table.md
├── vcfheader
│   ├── LICENSE
│   ├── NOTICE
│   ├── README.md
│   └── vcfheader
├── vcfheader_v0.1.0_macos_x86_64.tar.gz
└── vcfheader_v0.1.0_macos_x86_64.tar.gz.sha256
````

### Release publication 

The actual file to publish is the tar.gz. Each tarball contains a small folder. For example:

```text
vcfheader_v0.1.0_macos_x86_64.tar.gz.sha256
vcfheader_v0.1.0_macos_x86_64.tar.gz
└── vcfheader/
    ├── vcfheader
    ├── README.md
    ├── NOTICE
    └── LICENSE
```

## Install

Build from source:

```bash
cargo build --release
./target/release/vcfheader --help
```

## Usage

Generate a report:

`vcfheader report path/to/file.vcf.gz -o file_vcfheader.html`

If -o is omitted, the output path is derived like the R implementation: *_vcfheader.html.

## Development notes

This repo includes scripts to generate golden HTML outputs from the R implementation and to run byte-for-byte golden tests.

See scripts/gen_golden_from_r.sh.


## Updating from the R package

When the R package changes, run:

```bash
PKG_DIR="$HOME/so/src/vcfheader_package" bash scripts/update_from_r.sh
This updates:
assets/vcf_spec_index.json (embedded spec index)
fixtures/golden/*.html (golden outputs from R)
runs cargo test
```

## What to do with your existing `set_up.sh`

Keep it if you like, but `scripts/update_from_r.sh` should become the single canonical entry point.

## LICENSE

```text
vcfheader is distributed under the GNU General Public License, version 3 (GPL-3).

A copy of GPL-3 is available at:
https://www.gnu.org/licenses/gpl-3.0.txt
```
