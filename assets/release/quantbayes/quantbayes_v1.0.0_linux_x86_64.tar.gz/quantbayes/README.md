# QuantBayES C implementation

QuantBayES provides a Bayesian transform for quantifying evidence sufficiency in binary rule matrices.
Each row represents a variant and each column represents an evidence rule.
The method returns per variant posterior estimates, credible intervals, percentiles, and global summary statistics.

This repository contains the standalone C implementation of the Quant ES core.
The algorithm is deterministic, context free, and suitable for reproducible interpretation of binary evidence patterns.

---

# 1. Quick start (recommended, no installation)

1. Download the QuantBayES archive for your system from the Switzerland Omics website.

2. Extract it:

    ```sh
    tar -xzf quantbayes_v<version>_<platform>.tar.gz
    cd quantbayes
    ```

3. Run QuantBayES directly from the extracted directory:

    ```sh
    ./quantbayes <matrix_file> [--out basename] [--report] [--json]
    ```

    Example using the bundled test matrix:

    ```sh
    ./quantbayes example_data/test_matrix_01.txt
    ./quantbayes example_data/test_matrix_01.txt --out sample1
    ./quantbayes example_data/test_matrix_01.txt --report
    ./quantbayes example_data/test_matrix_01.txt --json
    ```

4. On macOS, if you see a security warning when running the binary for the first time, remove the quarantine attribute:

    ```sh
    xattr -d com.apple.quarantine quantbayes
    ```

No system installation is required.
The binary can be run from any location where you have read and execute permissions.

---

# 2. Building from source

From the project root:

```sh
make
````

This generates:

```sh
./quantbayes
```

Clean build artefacts:

```sh
make clean
```

---

# 3. Optional installation (advanced)

This step is optional and mainly intended for developers or system administrators.

To install into a custom prefix that you own, for example:

```sh
make install PREFIX=$HOME/.local
```

Then ensure the binary directory is on your PATH:

```sh
export PATH="$HOME/.local/bin:$PATH"
```

Installation into system locations such as `/usr/local` may require elevated permissions and is not required for normal use.
The release archives are designed to run in place, similar to common genomics tools such as plink and bcftools.

---

# 4. Command line usage

```text
quantbayes <matrix_file> [--out basename] [--report] [--json]
```

Options:

* `--out NAME`
  Sets the basename for output files. If omitted, it is derived from the input filename.

* `--report`
  Prints a human readable summary and writes a report file.

* `--json`
  Produces all outputs in JSON format instead of text.

* `--help`
  Displays usage information.

---

# 5. Input format

QuantBayES expects a plain text matrix:

* One row per variant
* Space separated values
* Allowed values: `0`, `1`, `NA`
* Columns correspond to independent evidence rules

Example:

```text
1 1 0 0 1 NA 1 1
1 0 1 0 0 1 1 NA
```

---

# 6. Output files

Given an input:

```text
path/to/matrix.txt
```

the default basename is:

```text
path/to/matrix
```

### Text output (default)

```text
NAME_quantbayes.txt
NAME_quantbayes_global.txt
NAME_quantbayes_report.txt    (with --report)
```

### JSON output (with --json)

```text
NAME_quantbayes.json
NAME_quantbayes_global.json
NAME_quantbayes_report.json   (with --report)
```

Text and JSON modes are mutually exclusive.

---

# 7. Raw text output structure

```text
k  m  theta_mean  theta_lower  theta_upper  percentile
```

* `k` – evidence count
* `m` – total evidence rules
* `theta_mean` – posterior mean
* `theta_lower`, `theta_upper` – credible interval bounds
* `percentile` – rank percentile (0 to 100)

Variants appear in the input order.

---

# 8. Global summary structure

```text
n_variants  m_rules  mean_theta  median_theta  lower_theta  upper_theta  ci_level
```

`lower_theta` and `upper_theta` follow R’s type 7 quantile rule.

---

# 9. Report mode

Enable with:

```sh
quantbayes matrix.txt --report
```

The report includes:

* ASCII header
* Input dimensions
* Top three variants by posterior mean
* Posterior summaries
* Global summary statistics

This content is also written to:

```text
NAME_quantbayes_report.txt   or   NAME_quantbayes_report.json
```

---

# 10. Method parity with the R implementation

The C engine matches the original R implementation.

### Per variant posterior

```text
alpha = a + k
beta  = b + m - k
theta_mean = alpha / (alpha + beta)
```

### Credible intervals

Exact Beta quantiles:

```text
theta_lower = qbeta((1 - ci)/2, alpha, beta)
theta_upper = qbeta(1 - (1 - ci)/2, alpha, beta)
```

### Percentiles

Ranks correspond to R with averaged ties:

```text
percentile = 100 * rank(theta_mean) / n
```

### Global credible intervals

Computed using R’s type 7 quantile.

---

# 11. Example scripts

Located in `scripts/`:

* `example_raw.sh`
* `example_report.sh`
* `run_examples.sh`

These reproduce the reference outputs in `tests/output/`.

---

# 12. Test dataset

Example data:

```text
tests/data/test_matrix_01.txt
```

Outputs produced by example scripts are stored in:

```text
tests/output/
```

---

# 13. Evidence encoding and NA values

QuantBayES operates on a binary evidence matrix where each entry expresses whether the available data provide verifiable support for an upstream result.
The model does not predict effect or causality; instead, it measures how much confirmatory evidence is present, independent of the algorithm that produced the initial finding.
High posterior values therefore correspond to strong, reproducible evidence support.

Most evidence rules follow the direct pattern where observing a feature contributes support.
For example, a disease causing genetic effect on protein structure:

```text
flag_uniprot_hits_any_feature:
    TRUE  → 1   feature present
    FALSE → 0   not present
    NA    → 0   missing; cannot contribute support
```

Some rules work in reverse, providing support when no contradiction is observed.
This is common in inheritance checks, where the absence of a conflict increases confidence in the result:

```text
flag_moi_parent_conflict_AD:
    TRUE  → 0   inheritance conflict observed
    FALSE → 1   inheritance consistent
    NA    → 1   no counterevidence recorded
```

In both cases, QuantBayES interprets the matrix strictly as evidence: `1` means support, `0` means lack of support or contradiction.
Missing values (`NA`) are treated conservatively and converted internally to `0`, unless upstream logic explicitly resolves them in a domain appropriate way.
The responsibility for generating this matrix lies with the user or with a dedicated rule system such as Quant ES Interpret from the Swiss Genomics Association.

This design keeps QuantBayES universal, reproducible, and independent of the underlying inference method.
It answers a single question: how much verifiable supporting evidence accompanies the result being evaluated.

---

# 14. Manual

The manual page can be viewed on most modern macOS and Linux systems:
```sh
man -l quantbayes.1
```

On systems where man -l is not available (common on HPC clusters):
```sh
groff -Tutf8 -man quantbayes.1 | less -R
```

# 15. Citation

Quant Group and Lawless, D. (2025).
*A Bayesian model for quantifying genomic variant evidence sufficiency in Mendelian disease.*
medRxiv.
[https://www.medrxiv.org/content/10.64898/2025.12.02.25341503v1](https://www.medrxiv.org/content/10.64898/2025.12.02.25341503v1)

---

# 16. Licence

MIT Licence.
See the `LICENSE` file.

